import React, { Component } from "react";
import { StyleSheet, View, TouchableOpacity } from "react-native";
import Icon from "react-native-vector-icons/MaterialIcons";
import LogoHeader from "./LogoHeader";

function HeaderX(props) {
  return (
    <View style={[styles.container, props.style]}>
      <View style={styles.groupStack}>
        <View style={styles.group}>
          <Icon name="chevron-left" style={styles.icon}></Icon>
          <View style={styles.iconFiller}>
            <LogoHeader style={styles.logoHeader}></LogoHeader>
          </View>
        </View>
        <TouchableOpacity
          onPress={() => console.log("Navigate to Go Back")}
          style={styles.button}
        ></TouchableOpacity>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    backgroundColor: "rgba(255,166,166,1)"
  },
  group: {
    top: 5,
    left: 0,
    width: 360,
    height: 55,
    backgroundColor: "rgba(255,166,166,1)",
    position: "absolute",
    flexDirection: "row"
  },
  icon: {
    color: "rgba(255,255,255,1)",
    fontSize: 50,
    width: 54,
    height: 53,
    marginLeft: 17,
    marginTop: -11
  },
  logoHeader: {
    width: 150,
    height: 35,
    marginTop: -5
  },
  iconFiller: {
    flex: 1,
    flexDirection: "row",
    justifyContent: "center"
  },
  button: {
    top: 0,
    left: 27,
    width: 31,
    height: 37,
    position: "absolute"
  },
  groupStack: {
    width: 360,
    height: 60,
    marginTop: 20
  }
});

export default HeaderX;
