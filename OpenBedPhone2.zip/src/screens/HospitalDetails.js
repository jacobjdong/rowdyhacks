import React, { Component } from "react";
import { StyleSheet, View, Text } from "react-native";
import MaterialCardWithImageAndTitle2 from "../components/MaterialCardWithImageAndTitle2";
import HeaderX from "../components/HeaderX";

function HospitalDetails(props) {
  return (
    <View style={styles.container}>
      <View style={styles.materialCardWithImageAndTitle1Stack}>
        <MaterialCardWithImageAndTitle2
          style={styles.materialCardWithImageAndTitle1}
        ></MaterialCardWithImageAndTitle2>
        <Text style={styles.text}>
          - 60 Open Intensive Care Unit Beds{"\n"}
          {"\n"}- 118 Open Non-ICU Beds{"\n"}
          {"\n"}Phone Number: (303) 689 - 4000
        </Text>
      </View>
      <HeaderX
        icon2Family="Feather"
        icon2Name="search"
        style={styles.headerX1}
      ></HeaderX>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1
  },
  materialCardWithImageAndTitle1: {
    top: 0,
    left: 0,
    height: 660,
    position: "absolute",
    right: 0
  },
  text: {
    top: 139,
    left: 18,
    width: 217,
    height: 70,
    color: "#121212",
    position: "absolute",
    fontFamily: "roboto-regular"
  },
  materialCardWithImageAndTitle1Stack: {
    height: 660,
    marginTop: 80
  },
  headerX1: {
    height: 80,
    elevation: 15,
    shadowOffset: {
      height: 7,
      width: 1
    },
    shadowColor: "rgba(0,0,0,1)",
    shadowOpacity: 0.1,
    shadowRadius: 5,
    marginTop: -740
  }
});

export default HospitalDetails;
