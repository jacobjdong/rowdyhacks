import React, { Component } from "react";
import styled, { css } from "styled-components";
import MaterialButtonSuccess1 from "../components/MaterialButtonSuccess1";
import MaterialRightIconTextbox from "../components/MaterialRightIconTextbox";
import { Link } from "react-router-dom";
import FontAwesomeIcon from "react-native-vector-icons/dist/FontAwesome";

function DeleteInfo(props) {
  return (
    <Stack>
      <Image1Stack>
        <Image1>
          <Rect1>
            <PatientDischarge>Patient Discharge</PatientDischarge>
          </Rect1>
          <MaterialButtonSuccess1Stack>
            <MaterialButtonSuccess1
              style={{
                top: 236,
                left: 275,
                width: 140,
                height: 36,
                position: "absolute",
                borderRadius: 100,
                borderColor: "#000000",
                borderWidth: 0,
                borderStyle: "solid"
              }}
            ></MaterialButtonSuccess1>
            <Rect2>
              <PatientName>Patient Name</PatientName>
              <MaterialRightIconTextbox
                style={{
                  width: 662,
                  height: 43,
                  backgroundColor: "rgba(255,255,255,1)",
                  borderRadius: 100,
                  borderColor: "#000000",
                  borderWidth: 1,
                  marginTop: 15,
                  marginLeft: 14,
                  borderStyle: "solid"
                }}
                textInput1="Name"
              ></MaterialRightIconTextbox>
              <ReasonForDischarge>Reason for Discharge</ReasonForDischarge>
              <TextInput2Stack>
                <TextInput2
                  placeholder=""
                  defaultValue=""
                  maxLength={300}
                  numberOfLines={5}
                  clearTextOnFocus={false}
                ></TextInput2>
                <TextInput1 placeholder="Details..."></TextInput1>
              </TextInput2Stack>
              <MaterialButtonSuccess1
                style={{
                  width: 140,
                  height: 36,
                  borderRadius: 100,
                  borderColor: "#000000",
                  borderWidth: 0,
                  marginTop: 18,
                  marginLeft: 275,
                  borderStyle: "solid"
                }}
              ></MaterialButtonSuccess1>
            </Rect2>
          </MaterialButtonSuccess1Stack>
        </Image1>
        <Logo1 src={require("../assets/images/logo1.png")}></Logo1>
      </Image1Stack>
      <Navmenu1Stack>
        <Navmenu1>
          <Link to="/PatientInfo">
            <Button1>
              <ButtonOverlay>
                <InfoText1>Enter New Patient Information</InfoText1>
              </ButtonOverlay>
            </Button1>
          </Link>
          <Link to="/UpdateInfo">
            <Button3>
              <ButtonOverlay>
                <Update1>Update Patient Information</Update1>
              </ButtonOverlay>
            </Button3>
          </Link>
          <Link to="/DeleteInfo">
            <Button5>
              <ButtonOverlay>
                <Delete1>Delete Patient Information</Delete1>
              </ButtonOverlay>
            </Button5>
          </Link>
          <Link to="/PatientDatabase">
            <Button2>
              <ButtonOverlay>
                <Database1>Patient Database</Database1>
              </ButtonOverlay>
            </Button2>
          </Link>
          <Link to="/Settings">
            <Button4>
              <ButtonOverlay>
                <Setttings1>Settings</Setttings1>
              </ButtonOverlay>
            </Button4>
          </Link>
        </Navmenu1>
        <CompanyHeader1>
          <CrossIcon1Row>
            <FontAwesomeIcon
              name="plus"
              style={{
                color: "rgba(255,4,4,1)",
                fontSize: 28,
                height: 28,
                width: 22
              }}
            ></FontAwesomeIcon>
            <BrynMawrHospital1>Bryn Mawr Hospital</BrynMawrHospital1>
          </CrossIcon1Row>
        </CompanyHeader1>
      </Navmenu1Stack>
    </Stack>
  );
}

const Stack = styled.div`
  height: 770px;
  position: relative;
  display: flex;
`;

const ButtonOverlay = styled.button`
 display: block;
 background: none;
 height: 100%;
 width: 100%;
 border:none
 `;
const Image1 = styled.div`
  top: 16px;
  left: 0px;
  width: 1133px;
  height: 730px;
  position: absolute;
  flex-direction: column;
  display: flex;
  background-image: url(${require("../assets/images/Triangle-White-Seamless-Patterns3.jpg")});
  background-size: cover;
`;

const Rect1 = styled.div`
  width: 700px;
  height: 62px;
  background-color: rgba(230, 230, 230,1);
  border-radius: 10px;
  border-color: #000000;
  border-width: 0px;
  flex-direction: column;
  display: flex;
  margin-top: 59px;
  margin-left: 197px;
  border-style: solid;
`;

const PatientDischarge = styled.span`
  font-family: Roboto;
  color: rgba(0,0,0,1);
  font-size: 40px;
  font-weight: regular;
  font-style: normal;
  margin-top: 11px;
  margin-left: 193px;
`;

const Rect2 = styled.div`
  top: 0px;
  left: 0px;
  width: 700px;
  height: 380px;
  background-color: rgba(230, 230, 230,1);
  position: absolute;
  border-radius: 15px;
  border-color: #000000;
  border-width: 0px;
  flex-direction: column;
  display: flex;
  border-style: solid;
`;

const PatientName = styled.span`
  font-family: Roboto;
  color: rgba(0,0,0,1);
  font-size: 20px;
  font-weight: regular;
  font-style: normal;
  margin-top: 3px;
  margin-left: 14px;
`;

const ReasonForDischarge = styled.span`
  font-family: Roboto;
  color: rgba(0,0,0,1);
  font-size: 20px;
  font-weight: regular;
  font-style: normal;
  margin-top: 35px;
  margin-left: 14px;
`;

const TextInput2 = styled.input`
  font-family: Roboto;
  top: 0px;
  left: 0px;
  width: 662px;
  height: 148px;
  background-color: rgba(255,255,255,1);
  color: rgba(0,0,0,0.6);
  position: absolute;
  border-radius: 15px;
  border-color: #000000;
  border-width: 1px;
  font-size: 16px;
  font-weight: regular;
  font-style: normal;
  border-style: solid;
  background: transparent;
`;

const TextInput1 = styled.input`
  font-family: Roboto;
  top: 6px;
  left: 14px;
  width: 633px;
  height: 136px;
  color: rgba(0,0,0,1);
  position: absolute;
  font-size: 16px;
  font-weight: regular;
  font-style: normal;
  border: none;
  background: transparent;
`;

const TextInput2Stack = styled.div`
  width: 662px;
  height: 148px;
  margin-top: 21px;
  margin-left: 15px;
  position: relative;
`;

const MaterialButtonSuccess1Stack = styled.div`
  width: 700px;
  height: 380px;
  margin-top: 87px;
  margin-left: 197px;
  position: relative;
`;

const Logo1 = styled.img`
  top: 0px;
  left: 1020px;
  width: 83px;
  height: 114px;
  position: absolute;
  object-fit: contain;
`;

const Image1Stack = styled.div`
  top: 24px;
  left: 267px;
  width: 1133px;
  height: 746px;
  position: absolute;
`;

const Navmenu1 = styled.div`
  top: 2px;
  left: 0px;
  width: 267px;
  height: 768px;
  background-color: rgba(255,166,166,1);
  position: absolute;
  flex-direction: column;
  display: flex;
`;

const Button1 = styled.div`
  width: 244px;
  height: 34px;
  border-radius: 5px;
  border-color: rgba(255,255,255,1);
  border-width: 1px;
  flex-direction: column;
  display: flex;
  margin-top: 80px;
  margin-left: 12px;
  border-style: solid;
`;

const InfoText1 = styled.span`
  font-family: Roboto;
  color: rgba(255,255,255,1);
  font-size: 16px;
  font-weight: regular;
  font-style: normal;
  margin-top: 9px;
  margin-left: 15px;
`;

const Button3 = styled.div`
  width: 244px;
  height: 34px;
  border-radius: 5px;
  border-color: rgba(255,255,255,1);
  border-width: 1px;
  flex-direction: column;
  display: flex;
  margin-top: 22px;
  margin-left: 12px;
  border-style: solid;
`;

const Update1 = styled.span`
  font-family: Roboto;
  color: rgba(255,255,255,1);
  font-size: 16px;
  font-weight: regular;
  font-style: normal;
  text-align: center;
  margin-top: 10px;
  margin-left: 24px;
`;

const Button5 = styled.div`
  width: 244px;
  height: 34px;
  border-radius: 5px;
  border-color: rgba(255,255,255,1);
  border-width: 1px;
  flex-direction: column;
  display: flex;
  margin-top: 23px;
  margin-left: 12px;
  border-style: solid;
`;

const Delete1 = styled.span`
  font-family: Roboto;
  color: rgba(255,255,255,1);
  font-size: 16px;
  font-weight: regular;
  font-style: normal;
  text-align: center;
  margin-top: 9px;
  margin-left: 24px;
`;

const Button2 = styled.div`
  width: 244px;
  height: 34px;
  border-radius: 5px;
  border-color: rgba(255,255,255,1);
  border-width: 1px;
  flex-direction: column;
  display: flex;
  margin-top: 24px;
  margin-left: 11px;
  border-style: solid;
`;

const Database1 = styled.span`
  font-family: Roboto;
  color: rgba(255,255,255,1);
  font-size: 16px;
  font-weight: regular;
  font-style: normal;
  text-align: center;
  margin-top: 9px;
  margin-left: 60px;
`;

const Button4 = styled.div`
  width: 244px;
  height: 34px;
  border-radius: 5px;
  border-color: rgba(255,255,255,1);
  border-width: 1px;
  flex-direction: column;
  display: flex;
  margin-top: 25px;
  margin-left: 10px;
  border-style: solid;
`;

const Setttings1 = styled.span`
  font-family: Roboto;
  color: rgba(255,255,255,1);
  font-size: 16px;
  font-weight: regular;
  font-style: normal;
  text-align: center;
  margin-top: 9px;
  margin-left: 93px;
`;

const CompanyHeader1 = styled.div`
  top: 0px;
  left: 0px;
  height: 40px;
  background-color: rgba(230, 230, 230,1);
  position: absolute;
  right: 0px;
  flex-direction: row;
  display: flex;
`;

const BrynMawrHospital1 = styled.span`
  font-family: Roboto;
  color: rgba(0,0,0,1);
  font-size: 20px;
  font-weight: regular;
  font-style: normal;
  margin-left: 11px;
  margin-top: 4px;
`;

const CrossIcon1Row = styled.div`
  height: 28px;
  flex-direction: row;
  display: flex;
  flex: 1 1 0%;
  margin-right: 1181px;
  margin-left: 12px;
  margin-top: 6px;
`;

const Navmenu1Stack = styled.div`
  top: 0px;
  left: 0px;
  height: 770px;
  position: absolute;
  right: 0px;
`;

export default DeleteInfo;
