import React, { Component } from "react";
import styled, { css } from "styled-components";
import { Link } from "react-router-dom";
import FontAwesomeIcon from "react-native-vector-icons/dist/FontAwesome";

function PatientDatabase(props) {
  return (
    <Stack>
      <Image2Stack>
        <Image2>
          <Rect7>
            <PatientDatabaseStyle>Patient Database</PatientDatabaseStyle>
          </Rect7>
          <Rect8StackStack>
            <Rect8Stack>
              <Rect8>
                <DateRow>
                  <Date>Date</Date>
                  <PatientsName>Patient&#39;s name</PatientsName>
                  <Sex>Sex</Sex>
                  <DateOfBirth>Date of Birth</DateOfBirth>
                  <Icu>ICU</Icu>
                  <Condition>Condition</Condition>
                </DateRow>
              </Rect8>
              <Rect23></Rect23>
              <Rect24></Rect24>
              <Rect25></Rect25>
              <Rect26></Rect26>
              <Rect27></Rect27>
            </Rect8Stack>
            <Rect9>
              <Rect10></Rect10>
              <LoremIpsum>
                03/28/2020 John Smith M 02/08/1959 Y Fever
              </LoremIpsum>
              <Rect11></Rect11>
              <LoremIpsum2>
                03/27/2020 Maria Lockhart F 03/09/2001 N Possible Corona Virus
              </LoremIpsum2>
              <Rect12></Rect12>
              <LoremIpsum3>
                02/25/2020 Demo McCdemoson M 02/25/1919 Y PTSD
              </LoremIpsum3>
              <Rect13></Rect13>
              <Rect14></Rect14>
              <Rect15></Rect15>
              <Rect16></Rect16>
              <Rect17></Rect17>
              <Rect18></Rect18>
              <Rect19></Rect19>
              <Rect20></Rect20>
              <Rect21></Rect21>
              <Rect22></Rect22>
            </Rect9>
          </Rect8StackStack>
        </Image2>
        <Image1 src={require("../assets/images/logo1.png")}></Image1>
      </Image2Stack>
      <Navmenu1Stack>
        <Navmenu1>
          <Link to="/PatientInfo">
            <Button1>
              <ButtonOverlay>
                <InfoText1>Enter New Patient Information</InfoText1>
              </ButtonOverlay>
            </Button1>
          </Link>
          <Link to="/UpdateInfo">
            <Button3>
              <ButtonOverlay>
                <Update1>Update Patient Information</Update1>
              </ButtonOverlay>
            </Button3>
          </Link>
          <Link to="/DeleteInfo">
            <Button5>
              <ButtonOverlay>
                <Delete1>Delete Patient Information</Delete1>
              </ButtonOverlay>
            </Button5>
          </Link>
          <Link to="/PatientDatabase">
            <Button2>
              <ButtonOverlay>
                <Database1>Patient Database</Database1>
              </ButtonOverlay>
            </Button2>
          </Link>
          <Link to="/Settings">
            <Button4>
              <ButtonOverlay>
                <Setttings1>Settings</Setttings1>
              </ButtonOverlay>
            </Button4>
          </Link>
        </Navmenu1>
        <CompanyHeader1>
          <CrossIcon1Row>
            <FontAwesomeIcon
              name="plus"
              style={{
                color: "rgba(255,4,4,1)",
                fontSize: 28,
                width: 22,
                height: 28
              }}
            ></FontAwesomeIcon>
            <BrynMawrHospital1>Bryn Mawr Hospital</BrynMawrHospital1>
          </CrossIcon1Row>
        </CompanyHeader1>
      </Navmenu1Stack>
    </Stack>
  );
}

const Stack = styled.div`
  height: 770px;
  position: relative;
  display: flex;
`;

const ButtonOverlay = styled.button`
 display: block;
 background: none;
 height: 100%;
 width: 100%;
 border:none
 `;
const Image2 = styled.div`
  top: 16px;
  left: 0px;
  width: 1133px;
  height: 730px;
  position: absolute;
  flex-direction: column;
  display: flex;
  background-image: url(${require("../assets/images/Triangle-White-Seamless-Patterns3.jpg")});
  background-size: cover;
`;

const Rect7 = styled.div`
  width: 580px;
  height: 65px;
  background-color: rgba(230, 230, 230,1);
  border-radius: 10px;
  border-color: #000000;
  border-width: 0px;
  flex-direction: column;
  display: flex;
  margin-top: 59px;
  margin-left: 261px;
  border-style: solid;
`;

const PatientDatabaseStyle = styled.span`
  font-family: Roboto;
  width: 305px;
  height: 40px;
  color: rgba(0,0,0,1);
  font-size: 40px;
  font-weight: regular;
  font-style: normal;
  margin-top: 13px;
  margin-left: 137px;
`;

const Rect8 = styled.div`
  top: 0px;
  left: 0px;
  width: 1000px;
  height: 30px;
  background-color: rgba(230, 230, 230,1);
  position: absolute;
  flex-direction: row;
  display: flex;
`;

const Date = styled.span`
  font-family: Roboto;
  width: 47px;
  height: 20px;
  color: rgba(0,0,0,1);
  border-color: #000000;
  border-width: 1px;
  font-size: 20px;
  font-weight: regular;
  font-style: normal;
  margin-top: 1px;
  border-style: solid;
`;

const PatientsName = styled.span`
  font-family: Roboto;
  width: 131px;
  height: 20px;
  color: rgba(0,0,0,1);
  font-size: 20px;
  font-weight: regular;
  font-style: normal;
  margin-left: 61px;
`;

const Sex = styled.span`
  font-family: Roboto;
  width: 32px;
  height: 20px;
  color: rgba(0,0,0,1);
  font-size: 20px;
  font-weight: regular;
  font-style: normal;
  margin-left: 115px;
  margin-top: 1px;
`;

const DateOfBirth = styled.span`
  font-family: Roboto;
  width: 111px;
  height: 20px;
  color: rgba(0,0,0,1);
  font-size: 20px;
  font-weight: regular;
  font-style: normal;
  margin-left: 36px;
  margin-top: 1px;
`;

const Icu = styled.span`
  font-family: Roboto;
  width: 31px;
  height: 20px;
  color: rgba(0,0,0,1);
  font-size: 20px;
  font-weight: regular;
  font-style: normal;
  margin-left: 41px;
  margin-top: 3px;
`;

const Condition = styled.span`
  font-family: Roboto;
  width: 85px;
  height: 20px;
  color: rgba(0,0,0,1);
  font-size: 20px;
  font-weight: regular;
  font-style: normal;
  margin-left: 54px;
  margin-top: 3px;
`;

const DateRow = styled.div`
  height: 23px;
  flex-direction: row;
  display: flex;
  flex: 1 1 0%;
  margin-right: 245px;
  margin-left: 11px;
  margin-top: 4px;
`;

const Rect23 = styled.div`
  top: 0px;
  left: 115px;
  width: 4px;
  height: 550px;
  background-color: rgba(230, 230, 230,1);
  position: absolute;
`;

const Rect24 = styled.div`
  top: 0px;
  left: 361px;
  width: 4px;
  height: 550px;
  background-color: rgba(230, 230, 230,1);
  position: absolute;
`;

const Rect25 = styled.div`
  top: 0px;
  left: 429px;
  width: 4px;
  height: 550px;
  background-color: rgba(230, 230, 230,1);
  position: absolute;
`;

const Rect26 = styled.div`
  top: 0px;
  left: 666px;
  width: 4px;
  height: 550px;
  background-color: rgba(230, 230, 230,1);
  position: absolute;
`;

const Rect27 = styled.div`
  top: 0px;
  left: 581px;
  width: 4px;
  height: 550px;
  background-color: rgba(230, 230, 230,1);
  position: absolute;
`;

const Rect8Stack = styled.div`
  top: 0px;
  left: 0px;
  width: 1000px;
  height: 550px;
  position: absolute;
`;

const Rect9 = styled.div`
  top: 30px;
  left: 0px;
  width: 1000px;
  height: 520px;
  background-color: rgba(230, 230, 230,1);
  position: absolute;
  flex-direction: column;
  overflow: scroll;
  display: flex;
`;

const Rect10 = styled.div`
  width: 1000px;
  height: 40px;
  background-color: rgba(255,255,255,1);
`;

const LoremIpsum = styled.span`
  font-family: Roboto;
  top: 8px;
  left: 5px;
  width: 723px;
  height: 20px;
  color: rgba(0,0,0,1);
  position: absolute;
  font-size: 20px;
  font-weight: regular;
  font-style: normal;
`;

const Rect11 = styled.div`
  width: 1000px;
  height: 40px;
  background-color: rgba(216, 216, 216,1);
`;

const LoremIpsum2 = styled.span`
  font-family: Roboto;
  top: 48px;
  left: 5px;
  width: 870px;
  height: 20px;
  color: rgba(0,0,0,1);
  position: absolute;
  font-size: 20px;
  font-weight: regular;
  font-style: normal;
`;

const Rect12 = styled.div`
  width: 1000px;
  height: 40px;
  background-color: rgba(255,255,255,1);
`;

const LoremIpsum3 = styled.span`
  font-family: Roboto;
  top: 89px;
  left: 5px;
  width: 726px;
  height: 20px;
  color: rgba(0,0,0,1);
  position: absolute;
  font-size: 20px;
  font-weight: regular;
  font-style: normal;
`;

const Rect13 = styled.div`
  width: 1000px;
  height: 40px;
  background-color: rgba(208,208,208,1);
`;

const Rect14 = styled.div`
  width: 1000px;
  height: 40px;
  background-color: rgba(255,255,255,1);
`;

const Rect15 = styled.div`
  width: 1000px;
  height: 40px;
  background-color: rgba(208,208,208,1);
`;

const Rect16 = styled.div`
  width: 1000px;
  height: 40px;
  background-color: rgba(255,255,255,1);
`;

const Rect17 = styled.div`
  width: 1000px;
  height: 40px;
  background-color: rgba(208,208,208,1);
`;

const Rect18 = styled.div`
  width: 1000px;
  height: 39px;
  background-color: rgba(255,255,255,1);
`;

const Rect19 = styled.div`
  width: 1000px;
  height: 40px;
  background-color: rgba(208,208,208,1);
`;

const Rect20 = styled.div`
  width: 1000px;
  height: 40px;
  background-color: rgba(255,255,255,1);
`;

const Rect21 = styled.div`
  width: 1000px;
  height: 40px;
  background-color: rgba(208,208,208,1);
`;

const Rect22 = styled.div`
  width: 1000px;
  height: 42px;
  background-color: rgba(255,255,255,1);
`;

const Rect8StackStack = styled.div`
  width: 1000px;
  height: 550px;
  margin-top: 31px;
  margin-left: 62px;
  position: relative;
`;

const Image1 = styled.img`
  top: 0px;
  left: 1020px;
  width: 83px;
  height: 114px;
  position: absolute;
  object-fit: contain;
`;

const Image2Stack = styled.div`
  top: 24px;
  left: 267px;
  width: 1133px;
  height: 746px;
  position: absolute;
`;

const Navmenu1 = styled.div`
  top: 2px;
  left: 0px;
  width: 267px;
  height: 768px;
  background-color: rgba(255,166,166,1);
  position: absolute;
  flex-direction: column;
  display: flex;
`;

const Button1 = styled.div`
  width: 244px;
  height: 34px;
  border-radius: 5px;
  border-color: rgba(255,255,255,1);
  border-width: 1px;
  flex-direction: column;
  display: flex;
  margin-top: 80px;
  margin-left: 12px;
  border-style: solid;
`;

const InfoText1 = styled.span`
  font-family: Roboto;
  width: 214px;
  height: 16px;
  color: rgba(255,255,255,1);
  font-size: 16px;
  font-weight: regular;
  font-style: normal;
  margin-top: 9px;
  margin-left: 15px;
`;

const Button3 = styled.div`
  width: 244px;
  height: 34px;
  border-radius: 5px;
  border-color: rgba(255,255,255,1);
  border-width: 1px;
  flex-direction: column;
  display: flex;
  margin-top: 22px;
  margin-left: 12px;
  border-style: solid;
`;

const Update1 = styled.span`
  font-family: Roboto;
  width: 192px;
  height: 16px;
  color: rgba(255,255,255,1);
  font-size: 16px;
  font-weight: regular;
  font-style: normal;
  text-align: center;
  margin-top: 10px;
  margin-left: 24px;
`;

const Button5 = styled.div`
  width: 244px;
  height: 34px;
  border-radius: 5px;
  border-color: rgba(255,255,255,1);
  border-width: 1px;
  flex-direction: column;
  display: flex;
  margin-top: 23px;
  margin-left: 12px;
  border-style: solid;
`;

const Delete1 = styled.span`
  font-family: Roboto;
  width: 186px;
  height: 16px;
  color: rgba(255,255,255,1);
  font-size: 16px;
  font-weight: regular;
  font-style: normal;
  text-align: center;
  margin-top: 9px;
  margin-left: 24px;
`;

const Button2 = styled.div`
  width: 244px;
  height: 34px;
  border-radius: 5px;
  border-color: rgba(255,255,255,1);
  border-width: 1px;
  flex-direction: column;
  display: flex;
  margin-top: 24px;
  margin-left: 11px;
  border-style: solid;
`;

const Database1 = styled.span`
  font-family: Roboto;
  width: 122px;
  height: 16px;
  color: rgba(255,255,255,1);
  font-size: 16px;
  font-weight: regular;
  font-style: normal;
  text-align: center;
  margin-top: 9px;
  margin-left: 60px;
`;

const Button4 = styled.div`
  width: 244px;
  height: 34px;
  border-radius: 5px;
  border-color: rgba(255,255,255,1);
  border-width: 1px;
  flex-direction: column;
  display: flex;
  margin-top: 25px;
  margin-left: 10px;
  border-style: solid;
`;

const Setttings1 = styled.span`
  font-family: Roboto;
  width: 58px;
  height: 16px;
  color: rgba(255,255,255,1);
  font-size: 16px;
  font-weight: regular;
  font-style: normal;
  text-align: center;
  margin-top: 9px;
  margin-left: 93px;
`;

const CompanyHeader1 = styled.div`
  top: 0px;
  left: 0px;
  height: 40px;
  background-color: rgba(230, 230, 230,1);
  position: absolute;
  right: 0px;
  flex-direction: row;
  display: flex;
`;

const BrynMawrHospital1 = styled.span`
  font-family: Roboto;
  width: 174px;
  height: 20px;
  color: rgba(0,0,0,1);
  font-size: 20px;
  font-weight: regular;
  font-style: normal;
  margin-left: 11px;
  margin-top: 4px;
`;

const CrossIcon1Row = styled.div`
  height: 28px;
  flex-direction: row;
  display: flex;
  flex: 1 1 0%;
  margin-right: 1181px;
  margin-left: 12px;
  margin-top: 6px;
`;

const Navmenu1Stack = styled.div`
  top: 0px;
  left: 0px;
  height: 770px;
  position: absolute;
  right: 0px;
`;

export default PatientDatabase;
