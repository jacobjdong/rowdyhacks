import React, { Component } from "react";
import {
  StyleSheet,
  View,
  TouchableOpacity,
  Text,
  StatusBar
} from "react-native";
import MaterialCardWithImageAndTitle2 from "../components/MaterialCardWithImageAndTitle2";
import MaterialCardWithImageAndTitle3 from "../components/MaterialCardWithImageAndTitle3";
import HeaderX from "../components/HeaderX";

function ListView(props) {
  return (
    <View style={styles.root}>
      <View style={styles.bodyStack}>
        <View style={styles.body}>
          <MaterialCardWithImageAndTitle2
            style={styles.materialCardWithImageAndTitle2}
          ></MaterialCardWithImageAndTitle2>
          <MaterialCardWithImageAndTitle3
            style={styles.materialCardWithImageAndTitle3}
          ></MaterialCardWithImageAndTitle3>
          <TouchableOpacity
            onPress={() => props.navigation.navigate("Welcome")}
            style={styles.button4}
          >
            <Text style={styles.home1}>Home</Text>
          </TouchableOpacity>
        </View>
        <HeaderX
          icon2Family="Feather"
          icon2Name="search"
          style={styles.headerX}
        ></HeaderX>
        <TouchableOpacity
          onPress={() => props.navigation.navigate("HospitalDetails")}
          style={styles.button2}
        ></TouchableOpacity>
        <TouchableOpacity
          onPress={() => props.navigation.navigate("HospitalDetails2")}
          style={styles.button3}
        ></TouchableOpacity>
      </View>
      <StatusBar
        barStyle="light-content"
        hidden={false}
        backgroundColor="rgba(0,0,0,0)"
      ></StatusBar>
    </View>
  );
}

const styles = StyleSheet.create({
  root: {
    flex: 1,
    backgroundColor: "rgb(255,255,255)"
  },
  body: {
    top: 80,
    width: 360,
    position: "absolute",
    bottom: 0,
    left: 0
  },
  materialCardWithImageAndTitle2: {
    width: 360,
    height: 141,
    marginTop: 94,
    alignSelf: "center"
  },
  materialCardWithImageAndTitle3: {
    width: 359,
    height: 142,
    marginLeft: 1
  },
  button4: {
    width: 132,
    height: 59,
    borderRadius: 25,
    borderColor: "#000000",
    borderWidth: 2,
    marginTop: 195,
    marginLeft: 114
  },
  home1: {
    color: "rgba(0,0,0,1)",
    fontSize: 30,
    fontFamily: "roboto-regular",
    marginTop: 15,
    marginLeft: 26
  },
  headerX: {
    top: 0,
    left: 0,
    height: 100,
    position: "absolute",
    elevation: 15,
    shadowOffset: {
      height: 7,
      width: 1
    },
    shadowColor: "rgba(0,0,0,1)",
    shadowOpacity: 0.1,
    shadowRadius: 5
  },
  button2: {
    top: 174,
    left: 1,
    width: 360,
    height: 141,
    position: "absolute"
  },
  button3: {
    top: 315,
    left: 1,
    width: 360,
    height: 142,
    position: "absolute"
  },
  bodyStack: {
    width: 361,
    flex: 1
  }
});

export default ListView;
