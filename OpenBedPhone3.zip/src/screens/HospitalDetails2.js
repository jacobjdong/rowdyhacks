import React, { Component } from "react";
import { StyleSheet, View, Text, TouchableOpacity } from "react-native";
import HeaderX from "../components/HeaderX";
import MaterialCardWithImageAndTitle3 from "../components/MaterialCardWithImageAndTitle3";

function HospitalDetails2(props) {
  return (
    <View style={styles.container}>
      <HeaderX icon2Name="power" style={styles.headerX1}></HeaderX>
      <View style={styles.materialCardWithImageAndTitle1Stack}>
        <MaterialCardWithImageAndTitle3
          style={styles.materialCardWithImageAndTitle1}
        ></MaterialCardWithImageAndTitle3>
        <Text style={styles.text1}>
          - 7 Open Intensive Care Unit Beds{"\n"}
          {"\n"}- 18 Open Non-ICU Beds{"\n"}
          {"\n"}Phone Number: (303) 430 - 5560
        </Text>
        <TouchableOpacity
          onPress={() => props.navigation.navigate("Welcome")}
          style={styles.button1}
        >
          <Text style={styles.home1}>Home</Text>
        </TouchableOpacity>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1
  },
  headerX1: {
    width: 360,
    height: 100,
    elevation: 15,
    shadowOffset: {
      height: 7,
      width: 1
    },
    shadowColor: "rgba(0,0,0,1)",
    shadowOpacity: 0.1,
    shadowRadius: 5,
    alignSelf: "center"
  },
  materialCardWithImageAndTitle1: {
    top: 0,
    left: 0,
    width: 359,
    height: 680,
    position: "absolute"
  },
  text1: {
    top: 142,
    left: 15,
    width: 217,
    height: 74,
    color: "#121212",
    position: "absolute",
    fontFamily: "roboto-regular"
  },
  button1: {
    top: 552,
    left: 113,
    width: 132,
    height: 59,
    position: "absolute",
    borderRadius: 25,
    borderColor: "#000000",
    borderWidth: 2
  },
  home1: {
    color: "rgba(0,0,0,1)",
    fontSize: 30,
    fontFamily: "roboto-regular",
    marginTop: 15,
    marginLeft: 26
  },
  materialCardWithImageAndTitle1Stack: {
    width: 359,
    height: 680,
    marginLeft: 1
  }
});

export default HospitalDetails2;
