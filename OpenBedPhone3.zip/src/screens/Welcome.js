import React, { Component } from "react";
import { StyleSheet, View, Text, Image, TouchableOpacity } from "react-native";
import LogoHeader from "../components/LogoHeader";

function Welcome(props) {
  return (
    <View style={styles.container}>
      <LogoHeader style={styles.logoHeader1}></LogoHeader>
      <Text style={styles.welcomeToOpenbed}>Welcome to Openbed</Text>
      <Image
        source={require("../assets/images/openbed1.png")}
        resizeMode="contain"
        style={styles.image}
      ></Image>
      <View style={styles.enterStack}>
        <Text style={styles.enter}>Enter</Text>
        <TouchableOpacity
          onPress={() => props.navigation.navigate("MapView")}
          style={styles.button}
        ></TouchableOpacity>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "rgba(255,166,166,1)"
  },
  logoHeader1: {
    width: 150,
    height: 35,
    marginTop: -71,
    alignSelf: "center"
  },
  welcomeToOpenbed: {
    width: 360,
    height: 100,
    color: "rgba(255,255,255,1)",
    fontSize: 50,
    fontFamily: "roboto-regular",
    textAlign: "center",
    marginTop: 212
  },
  image: {
    width: 200,
    height: 200,
    marginTop: 14,
    marginLeft: 80,
    alignSelf: "center"
  },
  enter: {
    top: 12,
    color: "rgba(255,255,255,1)",
    position: "absolute",
    fontSize: 50,
    fontFamily: "roboto-regular",
    left: 31
  },
  button: {
    top: 0,
    left: 0,
    width: 170,
    height: 73,
    position: "absolute",
    borderRadius: 25,
    borderColor: "rgba(255,255,255,1)",
    borderWidth: 2
  },
  enterStack: {
    width: 170,
    height: 73,
    marginTop: 19,
    marginLeft: 95
  }
});

export default Welcome;
