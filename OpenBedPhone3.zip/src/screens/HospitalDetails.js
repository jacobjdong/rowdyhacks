import React, { Component } from "react";
import { StyleSheet, View, Text, TouchableOpacity } from "react-native";
import MaterialCardWithImageAndTitle2 from "../components/MaterialCardWithImageAndTitle2";
import HeaderX from "../components/HeaderX";

function HospitalDetails(props) {
  return (
    <View style={styles.container}>
      <View style={styles.materialCardWithImageAndTitle1Stack}>
        <MaterialCardWithImageAndTitle2
          style={styles.materialCardWithImageAndTitle1}
        ></MaterialCardWithImageAndTitle2>
        <Text style={styles.text}>
          - 60 Open Intensive Care Unit Beds{"\n"}
          {"\n"}- 118 Open Non-ICU Beds{"\n"}
          {"\n"}Phone Number: (303) 689 - 4000
        </Text>
        <Text style={styles.home}>Home</Text>
        <TouchableOpacity
          onPress={() => props.navigation.navigate("Welcome")}
          style={styles.button}
        ></TouchableOpacity>
      </View>
      <HeaderX
        icon2Family="Feather"
        icon2Name="search"
        style={styles.headerX1}
      ></HeaderX>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1
  },
  materialCardWithImageAndTitle1: {
    top: 0,
    left: 0,
    width: 360,
    height: 695,
    position: "absolute"
  },
  text: {
    top: 135,
    left: 16,
    width: 217,
    height: 74,
    color: "#121212",
    position: "absolute",
    fontFamily: "roboto-regular"
  },
  home: {
    top: 567,
    color: "rgba(0,0,0,1)",
    position: "absolute",
    fontSize: 30,
    fontFamily: "roboto-regular",
    left: 140
  },
  button: {
    top: 554,
    width: 132,
    height: 59,
    position: "absolute",
    borderRadius: 25,
    borderColor: "#000000",
    borderWidth: 2,
    left: 114
  },
  materialCardWithImageAndTitle1Stack: {
    width: 360,
    height: 695,
    marginTop: 100
  },
  headerX1: {
    height: 100,
    elevation: 15,
    shadowOffset: {
      height: 7,
      width: 1
    },
    shadowColor: "rgba(0,0,0,1)",
    shadowOpacity: 0.1,
    shadowRadius: 5,
    marginTop: -795
  }
});

export default HospitalDetails;
