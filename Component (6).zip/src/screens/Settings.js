import React, { Component } from "react";
import styled, { css } from "styled-components";
import FontAwesomeIcon from "react-native-vector-icons/dist/FontAwesome";
import MaterialRightIconTextbox from "../components/MaterialRightIconTextbox";
import MaterialButtonSuccess1 from "../components/MaterialButtonSuccess1";

function Settings(props) {
  return (
    <Stack>
      <Rect1Stack>
        <Rect1>
          <Rect2>
            <InfoText1>Enter New Patient Information</InfoText1>
          </Rect2>
          <Rect4>
            <InfoText3>Update Patient Information</InfoText3>
          </Rect4>
          <Rect6>
            <InfoText5>Delete Patient Information</InfoText5>
          </Rect6>
          <Rect3>
            <InfoText2>Patient Database</InfoText2>
          </Rect3>
          <Rect5>
            <InfoText4>Settings</InfoText4>
          </Rect5>
        </Rect1>
        <CompanyHeader1>
          <CrossIcon1Row>
            <FontAwesomeIcon
              name="plus"
              style={{
                color: "rgba(255,4,4,1)",
                fontSize: 28,
                height: 28,
                width: 22
              }}
            ></FontAwesomeIcon>
            <BrynMawrHospital1>Bryn Mawr Hospital</BrynMawrHospital1>
          </CrossIcon1Row>
        </CompanyHeader1>
        <Image1 src={require("../assets/images/logo1.png")}></Image1>
      </Rect1Stack>
      <Rect7>
        <HospitalAddress>Hospital Address</HospitalAddress>
        <MaterialRightIconTextbox
          style={{
            width: 662,
            height: 43,
            borderRadius: 100,
            borderColor: "#000000",
            borderWidth: 1,
            marginTop: 14,
            marginLeft: 14,
            borderStyle: "solid"
          }}
        ></MaterialRightIconTextbox>
        <HospitalAddress1>Hospital Phone Number</HospitalAddress1>
        <MaterialRightIconTextbox
          style={{
            width: 662,
            height: 43,
            borderRadius: 100,
            borderColor: "#000000",
            borderWidth: 1,
            marginTop: 13,
            marginLeft: 14,
            borderStyle: "solid"
          }}
        ></MaterialRightIconTextbox>
        <MaterialButtonSuccess1
          style={{
            width: 140,
            height: 36,
            borderRadius: 100,
            borderColor: "#000000",
            borderWidth: 0,
            marginTop: 23,
            marginLeft: 275,
            borderStyle: "solid"
          }}
        ></MaterialButtonSuccess1>
      </Rect7>
      <Rect8>
        <HospitalInformation>Hospital Information</HospitalInformation>
      </Rect8>
    </Stack>
  );
}

const Stack = styled.div`
  height: 768px;
  position: relative;
  display: flex;
`;

const Rect1 = styled.div`
  top: 0px;
  left: 0px;
  width: 267px;
  height: 768px;
  background-color: rgba(255,166,166,1);
  position: absolute;
  flex-direction: column;
  display: flex;
`;

const Rect2 = styled.div`
  width: 244px;
  height: 34px;
  border-radius: 5px;
  border-color: rgba(255,255,255,1);
  border-width: 1px;
  flex-direction: column;
  display: flex;
  margin-top: 82px;
  margin-left: 12px;
  border-style: solid;
`;

const InfoText1 = styled.span`
  font-family: Roboto;
  color: rgba(255,255,255,1);
  font-size: 16px;
  font-weight: regular;
  font-style: normal;
  margin-top: 9px;
  margin-left: 15px;
`;

const Rect4 = styled.div`
  width: 244px;
  height: 34px;
  border-radius: 5px;
  border-color: rgba(255,255,255,1);
  border-width: 1px;
  flex-direction: column;
  display: flex;
  margin-top: 22px;
  margin-left: 12px;
  border-style: solid;
`;

const InfoText3 = styled.span`
  font-family: Roboto;
  color: rgba(255,255,255,1);
  font-size: 16px;
  font-weight: regular;
  font-style: normal;
  text-align: center;
  margin-top: 10px;
  margin-left: 24px;
`;

const Rect6 = styled.div`
  width: 244px;
  height: 34px;
  border-radius: 5px;
  border-color: rgba(255,255,255,1);
  border-width: 1px;
  flex-direction: column;
  display: flex;
  margin-top: 23px;
  margin-left: 12px;
  border-style: solid;
`;

const InfoText5 = styled.span`
  font-family: Roboto;
  color: rgba(255,255,255,1);
  font-size: 16px;
  font-weight: regular;
  font-style: normal;
  text-align: center;
  margin-top: 9px;
  margin-left: 24px;
`;

const Rect3 = styled.div`
  width: 244px;
  height: 34px;
  border-radius: 5px;
  border-color: rgba(255,255,255,1);
  border-width: 1px;
  flex-direction: column;
  display: flex;
  margin-top: 24px;
  margin-left: 11px;
  border-style: solid;
`;

const InfoText2 = styled.span`
  font-family: Roboto;
  color: rgba(255,255,255,1);
  font-size: 16px;
  font-weight: regular;
  font-style: normal;
  text-align: center;
  margin-top: 9px;
  margin-left: 60px;
`;

const Rect5 = styled.div`
  width: 244px;
  height: 34px;
  border-radius: 5px;
  border-color: rgba(255,255,255,1);
  border-width: 1px;
  flex-direction: column;
  display: flex;
  margin-top: 25px;
  margin-left: 10px;
  border-style: solid;
`;

const InfoText4 = styled.span`
  font-family: Roboto;
  color: rgba(255,255,255,1);
  font-size: 16px;
  font-weight: regular;
  font-style: normal;
  text-align: center;
  margin-top: 9px;
  margin-left: 93px;
`;

const CompanyHeader1 = styled.div`
  top: 0px;
  left: 0px;
  height: 40px;
  background-color: rgba(230, 230, 230,1);
  position: absolute;
  right: 0px;
  flex-direction: row;
  display: flex;
`;

const BrynMawrHospital1 = styled.span`
  font-family: Roboto;
  color: rgba(0,0,0,1);
  font-size: 20px;
  font-weight: regular;
  font-style: normal;
  margin-left: 11px;
  margin-top: 4px;
`;

const CrossIcon1Row = styled.div`
  height: 28px;
  flex-direction: row;
  display: flex;
  flex: 1 1 0%;
  margin-right: 1181px;
  margin-left: 12px;
  margin-top: 6px;
`;

const Image1 = styled.img`
  top: 30px;
  left: 1287px;
  width: 83px;
  height: 114px;
  position: absolute;
  object-fit: contain;
`;

const Rect1Stack = styled.div`
  top: 0px;
  left: 0px;
  height: 768px;
  position: absolute;
  right: 0px;
`;

const Rect7 = styled.div`
  top: 243px;
  left: 464px;
  width: 700px;
  height: 295px;
  background-color: rgba(230, 230, 230,1);
  position: absolute;
  border-radius: 15px;
  border-color: #000000;
  border-width: 0px;
  flex-direction: column;
  display: flex;
  border-style: solid;
`;

const HospitalAddress = styled.span`
  font-family: Roboto;
  color: rgba(0,0,0,1);
  font-size: 20px;
  font-weight: regular;
  font-style: normal;
  margin-top: 8px;
  margin-left: 14px;
`;

const HospitalAddress1 = styled.span`
  font-family: Roboto;
  color: rgba(0,0,0,1);
  font-size: 20px;
  font-weight: regular;
  font-style: normal;
  margin-top: 57px;
  margin-left: 14px;
`;

const Rect8 = styled.div`
  top: 107px;
  left: 464px;
  width: 700px;
  height: 62px;
  background-color: rgba(230, 230, 230,1);
  position: absolute;
  border-radius: 10px;
  border-color: #000000;
  border-width: 0px;
  flex-direction: column;
  display: flex;
  border-style: solid;
`;

const HospitalInformation = styled.span`
  font-family: Roboto;
  color: rgba(0,0,0,1);
  font-size: 40px;
  font-weight: regular;
  font-style: normal;
  margin-top: 11px;
  margin-left: 167px;
`;

export default Settings;
