import React, { Component } from "react";
import { StyleSheet, View, TouchableOpacity, StatusBar } from "react-native";
import HeaderX from "../components/HeaderX";
import MaterialCardWithImageAndTitle2 from "../components/MaterialCardWithImageAndTitle2";

function ListView(props) {
  return (
    <View style={styles.root}>
      <HeaderX
        icon2Family="Feather"
        icon2Name="search"
        style={styles.headerX}
      ></HeaderX>
      <View style={styles.body}>
        <View style={styles.materialCardWithImageAndTitle2Stack}>
          <MaterialCardWithImageAndTitle2
            style={styles.materialCardWithImageAndTitle2}
          ></MaterialCardWithImageAndTitle2>
          <TouchableOpacity
            onPress={() => props.navigation.navigate("HospitalDetails")}
            style={styles.button2}
          ></TouchableOpacity>
        </View>
      </View>
      <StatusBar
        barStyle="light-content"
        hidden={false}
        backgroundColor="rgba(0,0,0,0)"
      ></StatusBar>
    </View>
  );
}

const styles = StyleSheet.create({
  root: {
    flex: 1,
    backgroundColor: "rgb(255,255,255)"
  },
  headerX: {
    width: 360,
    height: 80,
    elevation: 15,
    shadowOffset: {
      height: 7,
      width: 1
    },
    shadowColor: "rgba(0,0,0,1)",
    shadowOpacity: 0.1,
    shadowRadius: 5
  },
  body: {
    width: 360,
    flex: 1,
    alignSelf: "center"
  },
  materialCardWithImageAndTitle2: {
    top: 0,
    width: 360,
    height: 141,
    position: "absolute",
    left: 0
  },
  button2: {
    top: 0,
    left: 0,
    width: 360,
    height: 141,
    position: "absolute"
  },
  materialCardWithImageAndTitle2Stack: {
    width: 360,
    height: 141,
    marginTop: 79
  }
});

export default ListView;
