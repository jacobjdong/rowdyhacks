import React, { Component } from "react";
import { StyleSheet, View, TouchableOpacity } from "react-native";
import Icon from "react-native-vector-icons/MaterialIcons";
import LogoHeader from "./LogoHeader";

function HeaderX(props) {
  return (
    <View style={[styles.container, props.style]}>
      <View style={styles.groupStack}>
        <View style={styles.group}>
          <View style={styles.iconRow}>
            <Icon name="chevron-left" style={styles.icon}></Icon>
            <LogoHeader style={styles.logoHeader}></LogoHeader>
          </View>
        </View>
        <TouchableOpacity
          onPress={() => console.log("Navigate to Go Back")}
          style={styles.button}
        ></TouchableOpacity>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    backgroundColor: "rgba(255,166,166,1)"
  },
  group: {
    top: 5,
    width: 360,
    height: 55,
    backgroundColor: "rgba(255,166,166,1)",
    position: "absolute",
    left: 0,
    flexDirection: "row"
  },
  icon: {
    color: "rgba(255,255,255,1)",
    fontSize: 50,
    width: 54,
    height: 53
  },
  logoHeader: {
    width: 150,
    height: 35,
    marginLeft: 34,
    marginTop: 6
  },
  iconRow: {
    height: 53,
    flexDirection: "row",
    flex: 1,
    marginRight: 105,
    marginLeft: 17,
    marginTop: -11
  },
  button: {
    top: 0,
    left: 27,
    width: 31,
    height: 37,
    position: "absolute"
  },
  groupStack: {
    width: 360,
    height: 60,
    marginTop: 20
  }
});

export default HeaderX;
