import React, { Component } from "react";
import styled, { css } from "styled-components";
import { Link } from "react-router-dom";
import FontAwesomeIcon from "react-native-vector-icons/dist/FontAwesome";

function Home(props) {
  return (
    <Stack>
      <ImageStack>
        <Image>
          <Center>
            <BedsAvailableRow>
              <BedsAvailable>Beds Available</BedsAvailable>
              <BedsOccupied>Beds Occupied</BedsOccupied>
            </BedsAvailableRow>
            <Line1StackRow>
              <Line1Stack>
                <Line1></Line1>
                <BedAvail>100</BedAvail>
              </Line1Stack>
              <Line2Stack>
                <Line2></Line2>
                <Bedocup>200</Bedocup>
              </Line2Stack>
            </Line1StackRow>
            <IcuBedsAvailableRow>
              <IcuBedsAvailable>ICU Beds Available</IcuBedsAvailable>
              <IcuBedsOccupied>ICU Beds Occupied</IcuBedsOccupied>
            </IcuBedsAvailableRow>
            <IcuavailRow>
              <Icuavail>20</Icuavail>
              <Icuocup>15</Icuocup>
            </IcuavailRow>
            <Line3Row>
              <Line3></Line3>
              <Line4></Line4>
            </Line3Row>
            <MaximumCapacity>Maximum Capacity</MaximumCapacity>
            <LoremIpsum8>325</LoremIpsum8>
            <Line5></Line5>
          </Center>
        </Image>
        <Rect1></Rect1>
        <Rect2></Rect2>
        <Rect3></Rect3>
        <Rect4></Rect4>
        <Rect5></Rect5>
        <Rect6></Rect6>
        <Logo src={require("../assets/images/logo1.png")}></Logo>
      </ImageStack>
      <NavmenuStack>
        <Navmenu>
          <Link to="/Home">
            <Button7>
              <ButtonOverlay>
                <Setttings2>Home</Setttings2>
              </ButtonOverlay>
            </Button7>
          </Link>
          <Link to="/PatientInfo">
            <Button>
              <ButtonOverlay>
                <InfoText>Enter New Patient Information</InfoText>
              </ButtonOverlay>
            </Button>
          </Link>
          <Link to="/UpdateInfo">
            <Button2>
              <ButtonOverlay>
                <Update>Update Patient Information</Update>
              </ButtonOverlay>
            </Button2>
          </Link>
          <Link to="/DeleteInfo">
            <Button3>
              <ButtonOverlay>
                <Delete>Patient Discharge</Delete>
              </ButtonOverlay>
            </Button3>
          </Link>
          <Link to="/PatientDatabase">
            <Button4>
              <ButtonOverlay>
                <Database>Patient Database</Database>
              </ButtonOverlay>
            </Button4>
          </Link>
          <Link to="/Settings">
            <Button5>
              <ButtonOverlay>
                <Setttings>Settings</Setttings>
              </ButtonOverlay>
            </Button5>
          </Link>
          <Link to="/Login">
            <Button6>
              <ButtonOverlay>
                <Setttings1>Logout</Setttings1>
              </ButtonOverlay>
            </Button6>
          </Link>
        </Navmenu>
        <Rect></Rect>
        <Rect7></Rect7>
        <CompanyHeader1>
          <CrossIcon1Row>
            <FontAwesomeIcon
              name="plus"
              style={{
                color: "rgba(255,4,4,1)",
                fontSize: 28,
                height: 28,
                width: 22
              }}
            ></FontAwesomeIcon>
            <BrynMawrHospital1>Bryn Mawr Hospital</BrynMawrHospital1>
          </CrossIcon1Row>
        </CompanyHeader1>
      </NavmenuStack>
    </Stack>
  );
}

const Stack = styled.div`
  height: 770px;
  margin-left: -1px;
  position: relative;
  display: flex;
`;

const ButtonOverlay = styled.button`
 display: block;
 background: none;
 height: 100%;
 width: 100%;
 border:none
 `;
const Image = styled.div`
  top: 38px;
  left: 267px;
  width: 1133px;
  height: 730px;
  position: absolute;
  flex-direction: column;
  display: flex;
  background-image: url(${require("../assets/images/Triangle-White-Seamless-Patterns3.jpg")});
  background-size: cover;
`;

const Center = styled.div`
  width: 625px;
  height: 431px;
  background-color: rgba(230, 230, 230,1);
  border-radius: 15px;
  border-color: #000000;
  border-width: 0px;
  flex-direction: column;
  display: flex;
  margin-top: 238px;
  margin-left: 245px;
  border-style: solid;
`;

const BedsAvailable = styled.span`
  font-family: Roboto;
  width: 130px;
  height: 20px;
  color: rgba(0,0,0,1);
  font-size: 20px;
  font-weight: regular;
  font-style: normal;
`;

const BedsOccupied = styled.span`
  font-family: Roboto;
  width: 133px;
  height: 20px;
  color: rgba(0,0,0,1);
  font-size: 20px;
  font-weight: regular;
  font-style: normal;
  margin-left: 191px;
`;

const BedsAvailableRow = styled.div`
  height: 20px;
  flex-direction: row;
  display: flex;
  margin-top: 41px;
  margin-left: 86px;
  margin-right: 85px;
`;

const Line1 = styled.div`
  top: 29px;
  left: 0px;
  width: 160px;
  height: 10px;
  background-color: rgba(0,0,0,1);
  position: absolute;
`;

const BedAvail = styled.span`
  font-family: Roboto;
  top: 0px;
  left: 54px;
  width: 51px;
  height: 30px;
  color: rgba(0,0,0,1);
  position: absolute;
  font-size: 30px;
  font-weight: regular;
  font-style: normal;
`;

const Line1Stack = styled.div`
  width: 160px;
  height: 39px;
  position: relative;
`;

const Line2 = styled.div`
  top: 29px;
  left: 0px;
  width: 160px;
  height: 10px;
  background-color: rgba(0,0,0,1);
  position: absolute;
`;

const Bedocup = styled.span`
  font-family: Roboto;
  top: 0px;
  left: 59px;
  width: 51px;
  height: 30px;
  color: rgba(0,0,0,1);
  position: absolute;
  font-size: 30px;
  font-weight: regular;
  font-style: normal;
`;

const Line2Stack = styled.div`
  width: 160px;
  height: 39px;
  margin-left: 163px;
  position: relative;
`;

const Line1StackRow = styled.div`
  height: 39px;
  flex-direction: row;
  display: flex;
  margin-top: 38px;
  margin-left: 71px;
  margin-right: 71px;
`;

const IcuBedsAvailable = styled.span`
  font-family: Roboto;
  width: 166px;
  height: 20px;
  color: rgba(0,0,0,1);
  font-size: 20px;
  font-weight: regular;
  font-style: normal;
`;

const IcuBedsOccupied = styled.span`
  font-family: Roboto;
  width: 170px;
  height: 20px;
  color: rgba(0,0,0,1);
  font-size: 20px;
  font-weight: regular;
  font-style: normal;
  margin-left: 161px;
`;

const IcuBedsAvailableRow = styled.div`
  height: 20px;
  flex-direction: row;
  display: flex;
  margin-top: 44px;
  margin-left: 67px;
  margin-right: 61px;
`;

const Icuavail = styled.span`
  font-family: Roboto;
  width: 34px;
  height: 30px;
  color: rgba(0,0,0,1);
  font-size: 30px;
  font-weight: regular;
  font-style: normal;
`;

const Icuocup = styled.span`
  font-family: Roboto;
  width: 34px;
  height: 30px;
  color: rgba(0,0,0,1);
  font-size: 30px;
  font-weight: regular;
  font-style: normal;
  margin-left: 294px;
`;

const IcuavailRow = styled.div`
  height: 30px;
  flex-direction: row;
  display: flex;
  margin-top: 30px;
  margin-left: 134px;
  margin-right: 129px;
`;

const Line3 = styled.div`
  width: 160px;
  height: 10px;
  background-color: rgba(0,0,0,1);
`;

const Line4 = styled.div`
  width: 160px;
  height: 10px;
  background-color: rgba(0,0,0,1);
  margin-left: 168px;
`;

const Line3Row = styled.div`
  height: 10px;
  flex-direction: row;
  display: flex;
  margin-top: 4px;
  margin-left: 71px;
  margin-right: 66px;
`;

const MaximumCapacity = styled.span`
  font-family: Roboto;
  width: 171px;
  height: 20px;
  color: rgba(0,0,0,1);
  font-size: 20px;
  font-weight: regular;
  font-style: normal;
  margin-top: 39px;
  margin-left: 226px;
`;

const LoremIpsum8 = styled.span`
  font-family: Roboto;
  width: 51px;
  height: 30px;
  color: rgba(0,0,0,1);
  font-size: 30px;
  font-weight: regular;
  font-style: normal;
  margin-top: 33px;
  margin-left: 287px;
`;

const Line5 = styled.div`
  width: 160px;
  height: 10px;
  background-color: rgba(0,0,0,1);
  margin-left: 232px;
`;

const Rect1 = styled.div`
  top: 302px;
  left: 0px;
  width: 268px;
  height: 25px;
  background-color: rgba(230, 230, 230,1);
  position: absolute;
  opacity: 0;
`;

const Rect2 = styled.div`
  top: 242px;
  left: 0px;
  width: 268px;
  height: 25px;
  background-color: rgba(230, 230, 230,1);
  position: absolute;
  opacity: 0;
`;

const Rect3 = styled.div`
  top: 183px;
  left: 0px;
  width: 268px;
  height: 25px;
  background-color: rgba(230, 230, 230,1);
  position: absolute;
  opacity: 0;
`;

const Rect4 = styled.div`
  top: 123px;
  left: 0px;
  width: 268px;
  height: 25px;
  background-color: rgba(230, 230, 230,1);
  position: absolute;
  opacity: 0;
`;

const Rect5 = styled.div`
  top: 38px;
  left: 0px;
  width: 268px;
  height: 50px;
  background-color: rgba(230, 230, 230,1);
  position: absolute;
  opacity: 0;
`;

const Rect6 = styled.div`
  top: 422px;
  left: 0px;
  width: 268px;
  height: 285px;
  background-color: rgba(230, 230, 230,1);
  position: absolute;
  opacity: 0;
`;

const Logo = styled.img`
  top: 0px;
  left: 663px;
  width: 323px;
  height: 285px;
  position: absolute;
  object-fit: contain;
`;

const ImageStack = styled.div`
  top: 2px;
  left: 1px;
  width: 1400px;
  height: 768px;
  position: absolute;
`;

const Navmenu = styled.div`
  top: 2px;
  left: 1px;
  width: 267px;
  height: 768px;
  background-color: rgba(255,166,166,1);
  position: absolute;
  flex-direction: column;
  display: flex;
`;

const Button7 = styled.div`
  width: 244px;
  height: 34px;
  border-radius: 5px;
  border-color: rgba(255,255,255,1);
  border-width: 1px;
  flex-direction: column;
  display: flex;
  margin-top: 88px;
  margin-left: 12px;
  border-style: solid;
`;

const Setttings2 = styled.span`
  font-family: Roboto;
  width: 58px;
  height: 16px;
  color: rgba(255,255,255,1);
  font-size: 16px;
  font-weight: regular;
  font-style: normal;
  text-align: center;
  margin-top: 9px;
  margin-left: 90px;
`;

const Button = styled.div`
  width: 244px;
  height: 34px;
  border-radius: 5px;
  border-color: rgba(255,255,255,1);
  border-width: 1px;
  flex-direction: column;
  display: flex;
  margin-top: 26px;
  margin-left: 11px;
  border-style: solid;
`;

const InfoText = styled.span`
  font-family: Roboto;
  width: 220px;
  height: 25px;
  color: rgba(255,255,255,1);
  font-size: 16px;
  font-weight: regular;
  font-style: normal;
  margin-top: 9px;
  margin-left: 10px;
`;

const Button2 = styled.div`
  width: 244px;
  height: 34px;
  border-radius: 5px;
  border-color: rgba(255,255,255,1);
  border-width: 1px;
  flex-direction: column;
  display: flex;
  margin-top: 26px;
  margin-left: 11px;
  border-style: solid;
`;

const Update = styled.span`
  font-family: Roboto;
  width: 220px;
  height: 25px;
  color: rgba(255,255,255,1);
  font-size: 16px;
  font-weight: regular;
  font-style: normal;
  text-align: center;
  margin-top: 9px;
  margin-left: 10px;
`;

const Button3 = styled.div`
  width: 244px;
  height: 34px;
  border-radius: 5px;
  border-color: rgba(255,255,255,1);
  border-width: 1px;
  flex-direction: column;
  display: flex;
  margin-top: 26px;
  margin-left: 11px;
  border-style: solid;
`;

const Delete = styled.span`
  font-family: Roboto;
  width: 220px;
  height: 25px;
  color: rgba(255,255,255,1);
  font-size: 16px;
  font-weight: regular;
  font-style: normal;
  text-align: center;
  margin-top: 9px;
  margin-left: 12px;
`;

const Button4 = styled.div`
  width: 244px;
  height: 34px;
  border-radius: 5px;
  border-color: rgba(255,255,255,1);
  border-width: 1px;
  flex-direction: column;
  display: flex;
  margin-top: 26px;
  margin-left: 12px;
  border-style: solid;
`;

const Database = styled.span`
  font-family: Roboto;
  width: 220px;
  height: 25px;
  color: rgba(255,255,255,1);
  font-size: 16px;
  font-weight: regular;
  font-style: normal;
  text-align: center;
  margin-top: 9px;
  margin-left: 9px;
`;

const Button5 = styled.div`
  width: 244px;
  height: 34px;
  border-radius: 5px;
  border-color: rgba(255,255,255,1);
  border-width: 1px;
  flex-direction: column;
  display: flex;
  margin-top: 26px;
  margin-left: 9px;
  border-style: solid;
`;

const Setttings = styled.span`
  font-family: Roboto;
  width: 58px;
  height: 16px;
  color: rgba(255,255,255,1);
  font-size: 16px;
  font-weight: regular;
  font-style: normal;
  text-align: center;
  margin-top: 8px;
  margin-left: 93px;
`;

const Button6 = styled.div`
  width: 244px;
  height: 34px;
  border-radius: 5px;
  border-color: rgba(255,255,255,1);
  border-width: 1px;
  flex-direction: column;
  display: flex;
  margin-top: 285px;
  margin-left: 12px;
  border-style: solid;
`;

const Setttings1 = styled.span`
  font-family: Roboto;
  width: 58px;
  height: 16px;
  color: rgba(255,255,255,1);
  font-size: 16px;
  font-weight: regular;
  font-style: normal;
  text-align: center;
  margin-top: 9px;
  margin-left: 88px;
`;

const Rect = styled.div`
  top: 364px;
  left: 0px;
  width: 268px;
  height: 25px;
  background-color: rgba(230, 230, 230,1);
  position: absolute;
  opacity: 0;
`;

const Rect7 = styled.div`
  top: 743px;
  left: 0px;
  width: 268px;
  height: 25px;
  background-color: rgba(230, 230, 230,1);
  position: absolute;
  opacity: 0;
`;

const CompanyHeader1 = styled.div`
  top: 0px;
  left: 1px;
  height: 40px;
  background-color: rgba(230, 230, 230,1);
  position: absolute;
  right: 0px;
  flex-direction: row;
  display: flex;
`;

const BrynMawrHospital1 = styled.span`
  font-family: Roboto;
  width: 174px;
  height: 20px;
  color: rgba(0,0,0,1);
  font-size: 20px;
  font-weight: regular;
  font-style: normal;
  margin-left: 11px;
  margin-top: 4px;
`;

const CrossIcon1Row = styled.div`
  height: 28px;
  flex-direction: row;
  display: flex;
  flex: 1 1 0%;
  margin-right: 1181px;
  margin-left: 12px;
  margin-top: 6px;
`;

const NavmenuStack = styled.div`
  top: 0px;
  left: 0px;
  height: 770px;
  position: absolute;
  right: 0px;
`;

export default Home;
