import React, { Component } from "react";
import styled, { css } from "styled-components";
import MaterialIconTextbox3 from "../components/MaterialIconTextbox3";
import MaterialIconTextbox6 from "../components/MaterialIconTextbox6";
import MaterialIconTextbox7 from "../components/MaterialIconTextbox7";
import MaterialIconTextbox4 from "../components/MaterialIconTextbox4";
import MaterialButtonSuccessV2 from "../components/MaterialButtonSuccessV2";
import { Link } from "react-router-dom";
import FontAwesomeIcon from "react-native-vector-icons/dist/FontAwesome";

function PatientInfo(props) {
  return (
    <Stack>
      <Image1Stack>
        <Image1>
          <Title>
            <PatientInformation>Patient Information</PatientInformation>
          </Title>
          <PatientName>Patient Name</PatientName>
          <MaterialIconTextbox3
            style={{
              width: 698,
              height: 43,
              backgroundColor: "rgba(255,255,255,1)",
              borderRadius: 100,
              borderColor: "#000000",
              borderWidth: 1,
              marginTop: 9,
              marginLeft: 187,
              borderStyle: "solid"
            }}
            textInput1=""
          ></MaterialIconTextbox3>
          <SexRow>
            <Sex>Sex</Sex>
            <Dob>Date of Birth</Dob>
          </SexRow>
          <MaterialIconTextbox7Row>
            <MaterialIconTextbox6
              style={{
                width: 300,
                height: 43,
                backgroundColor: "rgba(255,255,255,1)",
                borderRadius: 100,
                borderColor: "#000000",
                borderWidth: 1,
                borderStyle: "solid"
              }}
              textInput1=""
            ></MaterialIconTextbox6>
            <MaterialIconTextbox6
              style={{
                width: 300,
                height: 43,
                backgroundColor: "rgba(255,255,255,1)",
                borderRadius: 100,
                borderColor: "#000000",
                borderWidth: 1,
                marginLeft: 91,
                borderStyle: "solid"
              }}
            ></MaterialIconTextbox6>
          </MaterialIconTextbox7Row>
          <Gender1StackRow>
            <Gender1Stack>
              <Gender1></Gender1>
              <Icu>ICU</Icu>
            </Gender1Stack>
            <Admittance2>Date of Admittance</Admittance2>
          </Gender1StackRow>
          <MaterialIconTextbox72Row>
            <MaterialIconTextbox7
              style={{
                width: 300,
                height: 43,
                backgroundColor: "rgba(255,255,255,1)",
                borderRadius: 100,
                borderColor: "#000000",
                borderWidth: 1,
                marginTop: 3,
                borderStyle: "solid"
              }}
            ></MaterialIconTextbox7>
            <MaterialIconTextbox4
              style={{
                width: 300,
                height: 46,
                backgroundColor: "rgba(255,255,255,1)",
                borderRadius: 100,
                borderColor: "#000000",
                borderWidth: 1,
                marginLeft: 91,
                borderStyle: "solid"
              }}
              textInput1=""
            ></MaterialIconTextbox4>
          </MaterialIconTextbox72Row>
          <Conditions>Patient Admitted Conditions</Conditions>
          <DetailsStack>
            <Details
              placeholder=""
              autoCorrect={true}
              maxLength={300}
              selectTextOnFocus={false}
              disableFullscreenUI={false}
              numberOfLines={5}
              spellCheck={false}
            ></Details>
            <TextInput placeholder="Details..."></TextInput>
          </DetailsStack>
          <MaterialButtonSuccessV2
            style={{
              width: 200,
              height: 36,
              borderRadius: 93,
              borderColor: "#000000",
              borderWidth: 0,
              marginTop: 24,
              marginLeft: 436,
              borderStyle: "solid"
            }}
          ></MaterialButtonSuccessV2>
        </Image1>
        <Rect2></Rect2>
        <Rect3></Rect3>
        <Rect4></Rect4>
        <Rect5></Rect5>
        <Rect6></Rect6>
        <Logo src={require("../assets/images/logo1.png")}></Logo>
      </Image1Stack>
      <Navmenu1Stack>
        <Navmenu1>
          <Link to="/Home">
            <Button7>
              <ButtonOverlay>
                <Setttings3>Home</Setttings3>
              </ButtonOverlay>
            </Button7>
          </Link>
          <Link to="/PatientInfo">
            <Button1>
              <ButtonOverlay>
                <InfoText1>Enter New Patient Information</InfoText1>
              </ButtonOverlay>
            </Button1>
          </Link>
          <Link to="/UpdateInfo">
            <Button3>
              <ButtonOverlay>
                <Update1>Update Patient Information</Update1>
              </ButtonOverlay>
            </Button3>
          </Link>
          <Link to="/DeleteInfo">
            <Button5>
              <ButtonOverlay>
                <Delete1>Patient Discharge</Delete1>
              </ButtonOverlay>
            </Button5>
          </Link>
          <Link to="/PatientDatabase">
            <Button2>
              <ButtonOverlay>
                <Database1>Patient Database</Database1>
              </ButtonOverlay>
            </Button2>
          </Link>
          <Link to="/Settings">
            <Button4>
              <ButtonOverlay>
                <Setttings1>Settings</Setttings1>
              </ButtonOverlay>
            </Button4>
          </Link>
          <Link to="/Login">
            <Button6>
              <ButtonOverlay>
                <Setttings2>Logout</Setttings2>
              </ButtonOverlay>
            </Button6>
          </Link>
        </Navmenu1>
        <Rect1></Rect1>
        <Rect7></Rect7>
        <Rect8></Rect8>
        <CompanyHeader1>
          <CrossIcon1Row>
            <FontAwesomeIcon
              name="plus"
              style={{
                color: "rgba(255,4,4,1)",
                fontSize: 28,
                width: 22,
                height: 28
              }}
            ></FontAwesomeIcon>
            <BrynMawrHospital1>Bryn Mawr Hospital</BrynMawrHospital1>
          </CrossIcon1Row>
        </CompanyHeader1>
      </Navmenu1Stack>
    </Stack>
  );
}

const Stack = styled.div`
  height: 770px;
  margin-left: -1px;
  position: relative;
  display: flex;
`;

const ButtonOverlay = styled.button`
 display: block;
 background: none;
 height: 100%;
 width: 100%;
 border:none
 `;
const Image1 = styled.div`
  top: 16px;
  left: 267px;
  width: 1133px;
  height: 730px;
  position: absolute;
  flex-direction: column;
  display: flex;
  background-image: url(${require("../assets/images/Triangle-White-Seamless-Patterns3.jpg")});
  background-size: cover;
`;

const Title = styled.div`
  width: 698px;
  height: 64px;
  background-color: rgba(230, 230, 230,1);
  border-radius: 10px;
  border-color: #000000;
  border-width: 0px;
  flex-direction: column;
  display: flex;
  margin-top: 59px;
  margin-left: 187px;
  border-style: solid;
`;

const PatientInformation = styled.span`
  font-family: Roboto;
  width: 343px;
  height: 40px;
  color: #121212;
  font-size: 40px;
  font-weight: regular;
  font-style: normal;
  margin-top: 10px;
  margin-left: 174px;
`;

const PatientName = styled.span`
  font-family: Roboto;
  width: 97px;
  height: 16px;
  color: rgba(155,155,155,1);
  font-size: 16px;
  font-weight: regular;
  font-style: normal;
  margin-top: 31px;
  margin-left: 194px;
`;

const Sex = styled.span`
  font-family: Roboto;
  width: 26px;
  height: 16px;
  color: rgba(155,155,155,1);
  font-size: 16px;
  font-weight: regular;
  font-style: normal;
  margin-top: 1px;
`;

const Dob = styled.span`
  font-family: Roboto;
  width: 89px;
  height: 16px;
  color: rgba(155,155,155,1);
  font-size: 16px;
  font-weight: regular;
  font-style: normal;
  margin-left: 377px;
`;

const SexRow = styled.div`
  height: 17px;
  flex-direction: row;
  display: flex;
  margin-top: 15px;
  margin-left: 193px;
  margin-right: 448px;
`;

const MaterialIconTextbox7Row = styled.div`
  height: 43px;
  flex-direction: row;
  display: flex;
  margin-top: 4px;
  margin-left: 194px;
  margin-right: 248px;
`;

const Gender1 = styled.span`
  font-family: Roboto;
  top: 3px;
  left: 0px;
  width: 0px;
  height: 0px;
  color: rgba(155,155,155,1);
  position: absolute;
  font-size: 16px;
  font-weight: regular;
  font-style: normal;
`;

const Icu = styled.span`
  font-family: Roboto;
  top: 0px;
  left: 0px;
  width: 25px;
  height: 16px;
  color: rgba(155,155,155,1);
  position: absolute;
  font-size: 16px;
  font-weight: regular;
  font-style: normal;
`;

const Gender1Stack = styled.div`
  width: 25px;
  height: 16px;
  position: relative;
`;

const Admittance2 = styled.span`
  font-family: Roboto;
  width: 138px;
  height: 16px;
  color: rgba(155,155,155,1);
  font-size: 16px;
  font-weight: regular;
  font-style: normal;
  margin-left: 377px;
`;

const Gender1StackRow = styled.div`
  height: 16px;
  flex-direction: row;
  display: flex;
  margin-top: 24px;
  margin-left: 194px;
  margin-right: 399px;
`;

const MaterialIconTextbox72Row = styled.div`
  height: 46px;
  flex-direction: row;
  display: flex;
  margin-top: 3px;
  margin-left: 194px;
  margin-right: 248px;
`;

const Conditions = styled.span`
  font-family: Roboto;
  width: 200px;
  height: 16px;
  color: rgba(155,155,155,1);
  font-size: 16px;
  font-weight: regular;
  font-style: normal;
  margin-top: 18px;
  margin-left: 194px;
`;

const Details = styled.input`
  font-family: Roboto;
  top: 0px;
  left: 0px;
  width: 695px;
  height: 148px;
  background-color: rgba(255,255,255,1);
  color: rgba(0,0,0,0.6);
  position: absolute;
  border-radius: 15px;
  border-color: #000000;
  border-width: 1px;
  font-size: 16px;
  font-weight: regular;
  font-style: normal;
  line-height: 16px;
  border-style: solid;
  background: transparent;
`;

const TextInput = styled.input`
  font-family: Roboto;
  top: 6px;
  left: 15px;
  width: 665px;
  height: 136px;
  color: rgba(0,0,0,1);
  position: absolute;
  font-size: 16px;
  font-weight: regular;
  font-style: normal;
  border: none;
  background: transparent;
`;

const DetailsStack = styled.div`
  width: 695px;
  height: 148px;
  margin-top: 6px;
  margin-left: 189px;
  position: relative;
`;

const Rect2 = styled.div`
  top: 280px;
  left: 0px;
  width: 268px;
  height: 25px;
  background-color: rgba(230, 230, 230,1);
  position: absolute;
  opacity: 0;
`;

const Rect3 = styled.div`
  top: 220px;
  left: 0px;
  width: 268px;
  height: 25px;
  background-color: rgba(230, 230, 230,1);
  position: absolute;
  opacity: 0;
`;

const Rect4 = styled.div`
  top: 161px;
  left: 0px;
  width: 268px;
  height: 25px;
  background-color: rgba(230, 230, 230,1);
  position: absolute;
  opacity: 0;
`;

const Rect5 = styled.div`
  top: 101px;
  left: 0px;
  width: 268px;
  height: 25px;
  background-color: rgba(230, 230, 230,1);
  position: absolute;
  opacity: 0;
`;

const Rect6 = styled.div`
  top: 16px;
  left: 0px;
  width: 268px;
  height: 50px;
  background-color: rgba(230, 230, 230,1);
  position: absolute;
  opacity: 0;
`;

const Logo = styled.img`
  top: 0px;
  left: 1287px;
  width: 83px;
  height: 114px;
  position: absolute;
  object-fit: contain;
`;

const Image1Stack = styled.div`
  top: 24px;
  left: 1px;
  width: 1400px;
  height: 746px;
  position: absolute;
`;

const Navmenu1 = styled.div`
  top: 2px;
  left: 1px;
  width: 267px;
  height: 768px;
  background-color: rgba(255,166,166,1);
  position: absolute;
  flex-direction: column;
  display: flex;
`;

const Button7 = styled.div`
  width: 244px;
  height: 34px;
  border-radius: 5px;
  border-color: rgba(255,255,255,1);
  border-width: 1px;
  flex-direction: column;
  display: flex;
  margin-top: 88px;
  margin-left: 12px;
  border-style: solid;
`;

const Setttings3 = styled.span`
  font-family: Roboto;
  width: 58px;
  height: 16px;
  color: rgba(255,255,255,1);
  font-size: 16px;
  font-weight: regular;
  font-style: normal;
  text-align: center;
  margin-top: 9px;
  margin-left: 90px;
`;

const Button1 = styled.div`
  width: 244px;
  height: 34px;
  border-radius: 5px;
  border-color: rgba(255,255,255,1);
  border-width: 1px;
  flex-direction: column;
  display: flex;
  margin-top: 26px;
  margin-left: 11px;
  border-style: solid;
`;

const InfoText1 = styled.span`
  font-family: Roboto;
  width: 220px;
  height: 25px;
  color: rgba(255,255,255,1);
  font-size: 16px;
  font-weight: regular;
  font-style: normal;
  margin-top: 9px;
  margin-left: 10px;
`;

const Button3 = styled.div`
  width: 244px;
  height: 34px;
  border-radius: 5px;
  border-color: rgba(255,255,255,1);
  border-width: 1px;
  flex-direction: column;
  display: flex;
  margin-top: 26px;
  margin-left: 11px;
  border-style: solid;
`;

const Update1 = styled.span`
  font-family: Roboto;
  width: 220px;
  height: 25px;
  color: rgba(255,255,255,1);
  font-size: 16px;
  font-weight: regular;
  font-style: normal;
  text-align: center;
  margin-top: 9px;
  margin-left: 10px;
`;

const Button5 = styled.div`
  width: 244px;
  height: 34px;
  border-radius: 5px;
  border-color: rgba(255,255,255,1);
  border-width: 1px;
  flex-direction: column;
  display: flex;
  margin-top: 26px;
  margin-left: 11px;
  border-style: solid;
`;

const Delete1 = styled.span`
  font-family: Roboto;
  width: 220px;
  height: 25px;
  color: rgba(255,255,255,1);
  font-size: 16px;
  font-weight: regular;
  font-style: normal;
  text-align: center;
  margin-top: 9px;
  margin-left: 12px;
`;

const Button2 = styled.div`
  width: 244px;
  height: 34px;
  border-radius: 5px;
  border-color: rgba(255,255,255,1);
  border-width: 1px;
  flex-direction: column;
  display: flex;
  margin-top: 26px;
  margin-left: 12px;
  border-style: solid;
`;

const Database1 = styled.span`
  font-family: Roboto;
  width: 220px;
  height: 25px;
  color: rgba(255,255,255,1);
  font-size: 16px;
  font-weight: regular;
  font-style: normal;
  text-align: center;
  margin-top: 9px;
  margin-left: 9px;
`;

const Button4 = styled.div`
  width: 244px;
  height: 34px;
  border-radius: 5px;
  border-color: rgba(255,255,255,1);
  border-width: 1px;
  flex-direction: column;
  display: flex;
  margin-top: 26px;
  margin-left: 9px;
  border-style: solid;
`;

const Setttings1 = styled.span`
  font-family: Roboto;
  width: 58px;
  height: 16px;
  color: rgba(255,255,255,1);
  font-size: 16px;
  font-weight: regular;
  font-style: normal;
  text-align: center;
  margin-top: 8px;
  margin-left: 93px;
`;

const Button6 = styled.div`
  width: 244px;
  height: 34px;
  border-radius: 5px;
  border-color: rgba(255,255,255,1);
  border-width: 1px;
  flex-direction: column;
  display: flex;
  margin-top: 285px;
  margin-left: 12px;
  border-style: solid;
`;

const Setttings2 = styled.span`
  font-family: Roboto;
  width: 58px;
  height: 16px;
  color: rgba(255,255,255,1);
  font-size: 16px;
  font-weight: regular;
  font-style: normal;
  text-align: center;
  margin-top: 9px;
  margin-left: 88px;
`;

const Rect1 = styled.div`
  top: 364px;
  left: 0px;
  width: 268px;
  height: 25px;
  background-color: rgba(230, 230, 230,1);
  position: absolute;
  opacity: 0;
`;

const Rect7 = styled.div`
  top: 430px;
  left: 0px;
  width: 268px;
  height: 285px;
  background-color: rgba(230, 230, 230,1);
  position: absolute;
  opacity: 0;
`;

const Rect8 = styled.div`
  top: 743px;
  left: 0px;
  width: 268px;
  height: 25px;
  background-color: rgba(230, 230, 230,1);
  position: absolute;
  opacity: 0;
`;

const CompanyHeader1 = styled.div`
  top: 0px;
  left: 1px;
  height: 40px;
  background-color: rgba(230, 230, 230,1);
  position: absolute;
  right: 0px;
  flex-direction: row;
  display: flex;
`;

const BrynMawrHospital1 = styled.span`
  font-family: Roboto;
  width: 174px;
  height: 20px;
  color: rgba(0,0,0,1);
  font-size: 20px;
  font-weight: regular;
  font-style: normal;
  margin-left: 11px;
  margin-top: 4px;
`;

const CrossIcon1Row = styled.div`
  height: 28px;
  flex-direction: row;
  display: flex;
  flex: 1 1 0%;
  margin-right: 1181px;
  margin-left: 12px;
  margin-top: 6px;
`;

const Navmenu1Stack = styled.div`
  top: 0px;
  left: 0px;
  height: 770px;
  position: absolute;
  right: 0px;
`;

export default PatientInfo;
